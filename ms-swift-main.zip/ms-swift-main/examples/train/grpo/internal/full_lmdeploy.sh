# The LMDeploy backend in GRPO has been deprecated in Swift 3.5.
# You can install Swift 3.4 to continue using it with the following script:
# https://github.com/modelscope/ms-swift/blob/v3.4.1/examples/train/grpo/internal/full_lmdeploy.sh
