# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.ui import webui_main

if __name__ == '__main__':
    webui_main()
